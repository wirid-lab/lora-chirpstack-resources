# ESP32 LoRaWAN Mote (end node) #

Vist https://digitalelectronicsprojects.wordpress.com/2018/11/23/esp32-lorawan-mote/ for a full walk through of how too set it up.

Work on this is still in progress and the above code is used in the Arduino IDE and has been tried and tested on a Heltec WiFi LoRa V1 Board bought from here https://www.banggood.com/868MHz-915MHz-SX1276-ESP32-LoRa-0_96-Inch-Blue-OLED-Display-Bluetooth-WIFI-Lora-Kit-32-Module-p-1248583.html?rmmds=search&cur_warehouse=CN and set up on TTN which receives the data sent from the Mote and DHT22 sensor attached. Please read the README.md of all the libraries used within the repo for help in setting up till i get the how too done. CHEERS!!!! and have fun......

Download ZIP and on an Windows machine go to Documents->Arduino and extract there. Build one of the two examples in the root of the extracted folder for ESP32 and upload to the board. 

Full walk through is now up and ready for use at the above link. 28/11/2018.
